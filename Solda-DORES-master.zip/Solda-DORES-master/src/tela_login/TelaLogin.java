package tela_login;

import dao.UsuariosDAO;
import models.Usuarios;
import javax.swing.JOptionPane;
import util.Fonte;
import tela_principal.TelaPrincipal;
import java.sql.SQLException;
import util.Hash;

/**
 *
 * @author Hugo
 * @author Alex
 */

public class TelaLogin extends javax.swing.JFrame {

    public TelaLogin() {
        initComponents();
    }

    // Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        painel = new util.Gradiente();
        labelLogin = new javax.swing.JLabel();
        campoUsuario = new javax.swing.JTextField();
        mostrarSenha = new javax.swing.JToggleButton();
        campoSenha = new javax.swing.JPasswordField();
        labelCampoUsuario = new javax.swing.JLabel();
        labelCampoSenha = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        botaoEntrar = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        labelFrame = new javax.swing.JLabel();
        botaoSair = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        painel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelLogin.setFont(Fonte.inserirFonte("Baloo2-Bold.ttf", 48f));
        labelLogin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelLogin.setText("LOGIN");
        painel.add(labelLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 90, 570, 60));

        campoUsuario.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        campoUsuario.setBorder(null);
        campoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoUsuarioActionPerformed(evt);
            }
        });
        painel.add(campoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 200, 390, 30));

        mostrarSenha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/olho_aberto.png"))); // NOI18N
        mostrarSenha.setBorder(null);
        mostrarSenha.setBorderPainted(false);
        mostrarSenha.setContentAreaFilled(false);
        mostrarSenha.setFocusPainted(false);
        mostrarSenha.setFocusable(false);
        mostrarSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarSenhaActionPerformed(evt);
            }
        });
        painel.add(mostrarSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 290, -1, 30));

        campoSenha.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        campoSenha.setBorder(null);
        campoSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoSenhaActionPerformed(evt);
            }
        });
        painel.add(campoSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 290, 390, 30));

        labelCampoUsuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelCampoUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/campoTXT.png"))); // NOI18N
        painel.add(labelCampoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, 570, 50));

        labelCampoSenha.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelCampoSenha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/campoTXT.png"))); // NOI18N
        painel.add(labelCampoSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 280, 570, 50));

        jLabel5.setFont(Fonte.inserirFonte("Poppins-Regular.ttf", 18f));
        jLabel5.setForeground(new java.awt.Color(51, 153, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Recuperar senha");
        painel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 340, -1, -1));

        botaoEntrar.setFont(Fonte.inserirFonte("Baloo2-Bold.ttf", 36f));
        botaoEntrar.setForeground(new java.awt.Color(255, 255, 255));
        botaoEntrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoEntrar.setText("ENTRAR");
        botaoEntrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoEntrarMouseClicked(evt);
            }
        });
        painel.add(botaoEntrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 400, 270, 60));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_entrar.png"))); // NOI18N
        painel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 400, 270, 60));

        jLabel1.setFont(Fonte.inserirFonte("Baloo2-Bold.ttf", 18f));
        jLabel1.setForeground(new java.awt.Color(142, 142, 142));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icone_user.png"))); // NOI18N
        jLabel1.setText("Usuário");
        painel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 160, 100, -1));

        jLabel2.setFont(Fonte.inserirFonte("Baloo2-Bold.ttf", 18f));
        jLabel2.setForeground(new java.awt.Color(142, 142, 142));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icone_senha.png"))); // NOI18N
        jLabel2.setText("Senha");
        painel.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 250, 90, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/imagem_login.png"))); // NOI18N
        painel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 410, 470));

        labelFrame.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/frame.png"))); // NOI18N
        painel.add(labelFrame, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 60, -1, 500));

        botaoSair.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icone_sair.png"))); // NOI18N
        botaoSair.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoSairMouseClicked(evt);
            }
        });
        painel.add(botaoSair, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 10, -1, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(painel, javax.swing.GroupLayout.DEFAULT_SIZE,
                                javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(painel, javax.swing.GroupLayout.DEFAULT_SIZE,
                                javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

        setSize(new java.awt.Dimension(1012, 598));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void botaoSairMouseClicked(java.awt.event.MouseEvent evt) {
        // Função para sair da aplicação:
        System.exit(0);
    }

    private void campoSenhaActionPerformed(java.awt.event.ActionEvent evt) {
        botaoEntrarMouseClicked(null);
    }

    private void campoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {
        botaoEntrarMouseClicked(null); // botão entrar é invocado, então permite entrar com enter
    }

    private void mostrarSenhaActionPerformed(java.awt.event.ActionEvent evt) {
        // Função que mostrar os caracteres digitados no campo da senha:
        if (mostrarSenha.isSelected()) {
            campoSenha.setEchoChar((char) 0);
            mostrarSenha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/olho_aberto.png")));
        } else {
            campoSenha.setEchoChar(('•'));
            mostrarSenha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/olho_fechado.png")));
        }
    }

    private void botaoEntrarMouseClicked(java.awt.event.MouseEvent evt) {
        String login = campoUsuario.getText();
        String senha = new String(campoSenha.getPassword());

        if (login.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos");
            return;
        }

        // Como agora não existe mais a classe generica de login, foi preciso criar um objeto de usuario e usar o DAO
        try {
            UsuariosDAO dao = new UsuariosDAO();
            Usuarios usuario = dao.buscar_login(login);

            if (usuario == null) {
                JOptionPane.showMessageDialog(this, "Usuário não encontrado");
                return;
            }

            if (!usuario.isAtivo()) {
                JOptionPane.showMessageDialog(this, "Usuário inativo. Entre em contato com o administrador");
                return;
            }
            
            String senhaDigitadaHash = Hash.gerarHash(senha);
            // Aceita senha se for igual ao hash OU igual ao texto cru (para as contas já registradas no DB)
            if (!usuario.getSenha().equals(senhaDigitadaHash) && !usuario.getSenha().equals(senha)) {
                JOptionPane.showMessageDialog(this, "Senha incorreta");
                return;
            }

            // Guarda o usuário logado.
            tela_conta.Sessao.usuarioLogado = usuario;
            
            // Passou por todos os ifs, então temos senha correta, usuário ativo e correto. O sistema entra e fecha a telinha de login
            new TelaPrincipal().setVisible(true);
            dispose(); // esse cara aqui que faz fechar
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados:\n " + ex.getMessage());
        }
    }
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> {
            new TelaLogin().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel botaoEntrar;
    private javax.swing.JLabel botaoSair;
    private javax.swing.JPasswordField campoSenha;
    private javax.swing.JTextField campoUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel labelCampoSenha;
    private javax.swing.JLabel labelCampoUsuario;
    private javax.swing.JLabel labelFrame;
    private javax.swing.JLabel labelLogin;
    private javax.swing.JToggleButton mostrarSenha;
    private javax.swing.JPanel painel;
    // End of variables declaration//GEN-END:variables
}