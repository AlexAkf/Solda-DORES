package tela_principal;

import tela_relatorios.TelaRelatorios;
import tela_projetos.TelaProjetos;
import tela_empresas.TelaEmpresas;
import tela_funcionarios.TelaFuncionarios;
import tela_equipamentos.TelaEquipamentos;
import tela_dashboard.TelaDashboard;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import tela_conta.TelaConta;
import tela_informacoes.TelaInformacoes;
import util.Fonte;

/**
 *
 * @author Hugo
 * @author Alex
 */

public class TelaPrincipal extends javax.swing.JFrame {

    public TelaPrincipal() throws SQLException {
        initComponents();
        this.setExtendedState(TelaPrincipal.MAXIMIZED_BOTH);
        painelRecebedor.add(new TelaDashboard(), "Dashboard");
        painelRecebedor.add(new TelaFuncionarios(), "Funcionários");
        painelRecebedor.add(new TelaEquipamentos(), "Equipamentos");
        painelRecebedor.add(new TelaEmpresas(), "Empresas");
        painelRecebedor.add(new TelaProjetos(), "Projetos");
        painelRecebedor.add(new TelaRelatorios(), "Relatórios");
        painelRecebedor.add(new TelaConta(), "Conta");
        painelRecebedor.add(new TelaInformacoes(), "Informações");

        UIManager.put("ToolTip.foreground", Color.black);
        UIManager.put("ToolTip.background", Color.white);
        UIManager.put("ToolTip.font", new Font("Arial", Font.BOLD, 18));
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new util.Gradiente();
        botaoPesquisar = new javax.swing.JLabel();
        botaoConta = new javax.swing.JLabel();
        logo = new javax.swing.JLabel();
        botaoDashboard = new javax.swing.JLabel();
        botaoFuncionarios = new javax.swing.JLabel();
        botaoEquipamentos = new javax.swing.JLabel();
        botaoEmpresas = new javax.swing.JLabel();
        botaoProjetos = new javax.swing.JLabel();
        botaoRelatorios = new javax.swing.JLabel();
        selecionado = new javax.swing.JLabel();
        botaoSair = new javax.swing.JLabel();
        painelRecebedor = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(228, 228, 228));
        jPanel1.setMaximumSize(new java.awt.Dimension(1920, 1080));
        jPanel1.setMinimumSize(new java.awt.Dimension(1920, 1080));
        jPanel1.setPreferredSize(new java.awt.Dimension(1920, 1080));

        jPanel2.setMaximumSize(new java.awt.Dimension(100, 1080));
        jPanel2.setMinimumSize(new java.awt.Dimension(100, 1080));
        jPanel2.setPreferredSize(new java.awt.Dimension(100, 1080));
        jPanel2.setLayout(null);

        botaoPesquisar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_pesquisar.png"))); // NOI18N
        botaoPesquisar.setToolTipText("Pesquisar");
        botaoPesquisar.setMaximumSize(new java.awt.Dimension(54, 54));
        botaoPesquisar.setMinimumSize(new java.awt.Dimension(54, 54));
        botaoPesquisar.setPreferredSize(new java.awt.Dimension(54, 54));
        botaoPesquisar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoPesquisarMouseClicked(evt);
            }
        });
        jPanel2.add(botaoPesquisar);
        botaoPesquisar.setBounds(0, 20, 100, 54);

        botaoConta.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoConta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_conta.png"))); // NOI18N
        botaoConta.setToolTipText("Conta");
        botaoConta.setMaximumSize(new java.awt.Dimension(54, 54));
        botaoConta.setMinimumSize(new java.awt.Dimension(54, 54));
        botaoConta.setPreferredSize(new java.awt.Dimension(54, 54));
        botaoConta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoContaMouseClicked(evt);
            }
        });
        jPanel2.add(botaoConta);
        botaoConta.setBounds(0, 927, 100, 54);

        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logo.png"))); // NOI18N
        logo.setToolTipText("Informações");
        logo.setMaximumSize(new java.awt.Dimension(54, 54));
        logo.setMinimumSize(new java.awt.Dimension(54, 54));
        logo.setPreferredSize(new java.awt.Dimension(54, 54));
        logo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoMouseClicked(evt);
            }
        });
        jPanel2.add(logo);
        logo.setBounds(0, 1006, 100, 54);

        botaoDashboard.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoDashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_dashboard.png"))); // NOI18N
        botaoDashboard.setToolTipText("Dashboard");
        botaoDashboard.setMaximumSize(new java.awt.Dimension(54, 54));
        botaoDashboard.setMinimumSize(new java.awt.Dimension(54, 54));
        botaoDashboard.setPreferredSize(new java.awt.Dimension(54, 54));
        botaoDashboard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoDashboardMouseClicked(evt);
            }
        });
        jPanel2.add(botaoDashboard);
        botaoDashboard.setBounds(0, 160, 100, 54);

        botaoFuncionarios.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoFuncionarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_funcionarios.png"))); // NOI18N
        botaoFuncionarios.setToolTipText("Funcionários");
        botaoFuncionarios.setMaximumSize(new java.awt.Dimension(54, 54));
        botaoFuncionarios.setMinimumSize(new java.awt.Dimension(54, 54));
        botaoFuncionarios.setPreferredSize(new java.awt.Dimension(54, 54));
        botaoFuncionarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoFuncionariosMouseClicked(evt);
            }
        });
        jPanel2.add(botaoFuncionarios);
        botaoFuncionarios.setBounds(0, 249, 100, 54);

        botaoEquipamentos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoEquipamentos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_equipamentos.png"))); // NOI18N
        botaoEquipamentos.setToolTipText("Equipamentos");
        botaoEquipamentos.setPreferredSize(new java.awt.Dimension(54, 54));
        botaoEquipamentos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoEquipamentosMouseClicked(evt);
            }
        });
        jPanel2.add(botaoEquipamentos);
        botaoEquipamentos.setBounds(0, 338, 100, 54);

        botaoEmpresas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoEmpresas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_empresas.png"))); // NOI18N
        botaoEmpresas.setToolTipText("Empresas");
        botaoEmpresas.setMaximumSize(new java.awt.Dimension(54, 54));
        botaoEmpresas.setMinimumSize(new java.awt.Dimension(54, 54));
        botaoEmpresas.setPreferredSize(new java.awt.Dimension(54, 54));
        botaoEmpresas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoEmpresasMouseClicked(evt);
            }
        });
        jPanel2.add(botaoEmpresas);
        botaoEmpresas.setBounds(0, 427, 100, 54);

        botaoProjetos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoProjetos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_projetos.png"))); // NOI18N
        botaoProjetos.setToolTipText("Projetos");
        botaoProjetos.setMaximumSize(new java.awt.Dimension(54, 54));
        botaoProjetos.setMinimumSize(new java.awt.Dimension(54, 54));
        botaoProjetos.setPreferredSize(new java.awt.Dimension(54, 54));
        botaoProjetos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoProjetosMouseClicked(evt);
            }
        });
        jPanel2.add(botaoProjetos);
        botaoProjetos.setBounds(0, 516, 100, 54);

        botaoRelatorios.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoRelatorios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/botao_relatorios.png"))); // NOI18N
        botaoRelatorios.setToolTipText("Relatórios");
        botaoRelatorios.setMaximumSize(new java.awt.Dimension(54, 54));
        botaoRelatorios.setMinimumSize(new java.awt.Dimension(54, 54));
        botaoRelatorios.setPreferredSize(new java.awt.Dimension(54, 54));
        botaoRelatorios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoRelatoriosMouseClicked(evt);
            }
        });
        jPanel2.add(botaoRelatorios);
        botaoRelatorios.setBounds(0, 605, 100, 54);

        selecionado.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        selecionado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/selecionado.png"))); // NOI18N
        jPanel2.add(selecionado);
        selecionado.setBounds(0, 150, 100, 70);

        botaoSair.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botaoSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icone_sair.png"))); // NOI18N
        botaoSair.setToolTipText("Sair");
        botaoSair.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoSairMouseClicked(evt);
            }
        });

        painelRecebedor.setBackground(new java.awt.Color(228, 228, 228));
        painelRecebedor.setMaximumSize(new java.awt.Dimension(1810, 1014));
        painelRecebedor.setMinimumSize(new java.awt.Dimension(1810, 1014));
        painelRecebedor.setPreferredSize(new java.awt.Dimension(1810, 1014));
        painelRecebedor.setLayout(new java.awt.CardLayout());

        titulo.setFont(Fonte.inserirFonte("Baloo2-Bold.ttf", 29f));
        titulo.setForeground(new java.awt.Color(30, 58, 138));
        titulo.setText("DASHBOARD");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(titulo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botaoSair))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(painelRecebedor, javax.swing.GroupLayout.PREFERRED_SIZE, 1810, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1086, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(botaoSair)
                    .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(painelRecebedor, javax.swing.GroupLayout.PREFERRED_SIZE, 1014, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void botaoContaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoContaMouseClicked
        CardLayout cl = (CardLayout) painelRecebedor.getLayout();
        cl.show(painelRecebedor, "Conta");
        selecionado.setLocation(0, 920);
        titulo.setText("CONTA");
    }//GEN-LAST:event_botaoContaMouseClicked

    private void logoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoMouseClicked
        CardLayout cl = (CardLayout) painelRecebedor.getLayout();
        cl.show(painelRecebedor, "Informações");
        selecionado.setLocation(0, 1000);
        titulo.setText("INFORMAÇÕES");
    }//GEN-LAST:event_logoMouseClicked

    private void botaoSairMouseClicked(java.awt.event.MouseEvent evt) {
        System.exit(0);
    }

    private void botaoDashboardMouseClicked(java.awt.event.MouseEvent evt) {
        CardLayout cl = (CardLayout) painelRecebedor.getLayout();
        cl.show(painelRecebedor, "Dashboard");
        selecionado.setLocation(0, 150);
        titulo.setText("DASHBOARD");
    }

    private void botaoFuncionariosMouseClicked(java.awt.event.MouseEvent evt) {
        CardLayout cl = (CardLayout) painelRecebedor.getLayout();
        cl.show(painelRecebedor, "Funcionários");
        selecionado.setLocation(0, 239);
        titulo.setText("FUNCIONÁRIOS");
    }

    private void botaoEquipamentosMouseClicked(java.awt.event.MouseEvent evt) {
        CardLayout cl = (CardLayout) painelRecebedor.getLayout();
        selecionado.setLocation(0, 328);
        titulo.setText("EQUIPAMENTOS");
        cl.show(painelRecebedor, "Equipamentos");
    }

    private void botaoEmpresasMouseClicked(java.awt.event.MouseEvent evt) {
        CardLayout cl = (CardLayout) painelRecebedor.getLayout();
        selecionado.setLocation(0, 417);
        titulo.setText("EMPRESAS");
        cl.show(painelRecebedor, "Empresas");
    }

    private void botaoProjetosMouseClicked(java.awt.event.MouseEvent evt) {
        CardLayout cl = (CardLayout) painelRecebedor.getLayout();
        selecionado.setLocation(0, 506);
        titulo.setText("PROJETOS");
        cl.show(painelRecebedor, "Projetos");
    }

    private void botaoRelatoriosMouseClicked(java.awt.event.MouseEvent evt) {
        CardLayout cl = (CardLayout) painelRecebedor.getLayout();
        selecionado.setLocation(0, 595);
        titulo.setText("RELATÓRIOS");
        cl.show(painelRecebedor, "Relatórios");
    }

    private void botaoPesquisarMouseClicked(java.awt.event.MouseEvent evt) {
        BarraPesquisar barra = new BarraPesquisar(this);
        barra.setVisible(true);
    }
    
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        }
        java.awt.EventQueue.invokeLater(() -> {
            try {
                new TelaPrincipal().setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel botaoConta;
    private javax.swing.JLabel botaoDashboard;
    private javax.swing.JLabel botaoEmpresas;
    private javax.swing.JLabel botaoEquipamentos;
    private javax.swing.JLabel botaoFuncionarios;
    private javax.swing.JLabel botaoPesquisar;
    private javax.swing.JLabel botaoProjetos;
    private javax.swing.JLabel botaoRelatorios;
    private javax.swing.JLabel botaoSair;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel logo;
    private javax.swing.JPanel painelRecebedor;
    private javax.swing.JLabel selecionado;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}